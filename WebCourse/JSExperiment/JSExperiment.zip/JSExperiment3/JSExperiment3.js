function shift(fileName)
{
    var big = document.getElementById("bigID") ;
    big.src = "src/" + fileName + ".jpg" ;
}
